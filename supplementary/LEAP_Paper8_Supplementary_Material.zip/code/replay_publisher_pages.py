#!/usr/bin/env python3
"""Post-hoc W9 publisher-display comparison, with no historical candidate IDs.
Usage: python3 -B code/replay_publisher_pages.py data/source_records.zip OUT
Uses frozen captures only. Original locked predictions and outcomes remain unchanged.
Diagnostic captures are selected earlier worked examples, not independent holdout RFCs.
"""
import csv, datetime as dt, gzip, hashlib, json, re, sys, zipfile
from collections import Counter
from pathlib import Path
from replay_update_date import html_ids
from replay_full_registry import select, rfc, score
ROOT='LEAP_Paper8_R35_Research/'
def sha(b): return hashlib.sha256(b).hexdigest()
def ids(s): return ';'.join(map(str,sorted(s)))
def main(archive,out):
    out.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        def read(n): return z.read(ROOT+n)
        def j(n): return json.loads(read(n))
        raw=gzip.decompress(read('errata/registry.json.gz'))
        assert sha(raw)==j('errata/source.json')['sha256']
        current={int(x['errata_id']):x for x in json.loads(raw)}
        assert len(current)==8190
        def predictions(n,date):
            # No earlier IDs, historical status, or page contents enter this function.
            pool={i:x for i,x in current.items() if rfc(x['doc-id'])==n}
            p,invalid=select(pool,date);assert not any(invalid.values())
            return {'status':{i for i,x in pool.items() if x['errata_status_code']=='Verified'}, **p}
        lock=j('publisher_holdout/PREDICTION_LOCK.json'); frozen=j('publisher_holdout/predictions.json')
        assert sha(read('publisher_holdout/predictions.json'))==lock['sha256']
        assert sha(read('publisher_holdout/PROTOCOL.md'))==lock['protocol_sha256']
        assert frozen['november_sha256']==sha(raw)
        rows=[]; details=[]
        def record(group,n,cutoff,source,preds,obs,sha256,available,original_universe=None):
            # Missing capture is not scored. Compare complete displayed set (no intersection).
            for name,p in preds.items():
                row=dict(group=group,rfc=n,cutoff=str(cutoff),source=source,available=int(available),selector=name,observed_ids=ids(obs) if available else '',predicted_ids=ids(p),source_sha256=sha256,additions='',omissions='',exact='',outside_locked_universe='')
                if available:
                    s=score(p,obs);row.update(additions=s['added'],omissions=s['omitted'],exact=s['exact'])
                    if original_universe is not None: row['outside_locked_universe']=len(p-original_universe)
                    for i in sorted(p^obs):details.append(dict(group=group,rfc=n,cutoff=str(cutoff),selector=name,id=i,error='extra' if i in p else 'omitted',source=source))
                rows.append(row)
        cutoff=dt.date(2023,1,29)
        for group,ps in frozen['selection'].items():
            for entry in ps:
                n=entry['rfc']; p=predictions(n,cutoff); p['locked_dated']=set(entry['january']);f=j(f'publisher_holdout/fetch_logs/{n}.json')
                if f['available']:
                    rawpage=gzip.decompress(read('publisher_holdout/'+f['path'])); assert sha(rawpage)==f['sha256']
                    assert re.search(r'<title>\s*RFC\s*'+str(n)+r'\s*</title>',rawpage.decode(),re.I)
                    obs=html_ids(rawpage)
                else:obs=set();rawpage=b''
                record('locked_'+group,n,cutoff,f.get('path') or 'no qualifying capture',p,obs,sha(rawpage) if f['available'] else '',f['available'],set(entry['universe']))
        info=j('errata/inline_sources.json')
        for name,m in sorted(info.items()):
            if '_' not in name:continue
            n=int(m['rfc']); cutoff=dt.datetime.strptime(name.split('_')[1],'%Y%m%d%H%M%S').date(); p=predictions(n,cutoff)
            rawpage=gzip.decompress(read('errata/inline_'+name+'.html.gz'));assert sha(rawpage)==m['sha256'];assert m['http_status']==200
            assert re.search(r'<title>\s*RFC\s*'+str(n)+r'\s*</title>',rawpage.decode(),re.I)
            record('earlier_diagnostic',n,cutoff,m['url'],p,html_ids(rawpage),sha(rawpage),True)
        agg=[]
        for group in sorted({r['group'] for r in rows}):
            for selector in sorted({r['selector'] for r in rows if r['group']==group}):
                ss=[r for r in rows if r['group']==group and r['selector']==selector];valid=[r for r in ss if r['available']]
                agg.append(dict(group=group,selector=selector,selected=len(ss),scored=len(valid),exact=sum(r['exact'] for r in valid),additions=sum(r['additions'] for r in valid),omissions=sum(r['omissions'] for r in valid),outside_locked_universe=sum(r['outside_locked_universe'] for r in valid if isinstance(r['outside_locked_universe'],int))))
        assert len([r for r in rows if r['selector']=='status' and r['available']])==29
        assert len([r for r in rows if r['selector']=='status' and r['group']=='earlier_diagnostic'])==6
        assert all(r['available']==0 for r in rows if r['rfc']==6840 and r['group']=='locked_agreement')
        # Two methods use the same current registry and dated field; preserve all results, including failures.
        def dump(name,rr):
            with (out/name).open('w',encoding='utf-8',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
        dump('page_predictions.csv',rows);dump('summary.csv',agg);dump('membership_errors.csv',details)
        report=dict(scope='Retrospective replay on 23 original locked pages plus six previously known diagnostic captures (three RFCs); no fresh retrieval; no earlier-ID inputs for current-only rules; raw displayed ID sets used without restriction. Diagnostic captures are not holdout observations.',current_records=len(current),archive_sha256=sha(archive.read_bytes()),source_sha256=frozen['november_sha256'],prediction_lock_sha256=lock['sha256'],summary=agg)
        (out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(agg,indent=2))
if __name__=='__main__':main(Path(sys.argv[1]),Path(sys.argv[2]))
