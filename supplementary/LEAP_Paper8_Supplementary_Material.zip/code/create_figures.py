#!/usr/bin/env python3
"""Render manuscript figures from the recorded source data."""
import csv, json, hashlib, math
from pathlib import Path
from collections import Counter
from datetime import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, PathPatch
from matplotlib.path import Path as MPath
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'figure_data'; OUT=ROOT/'figures'; OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'Liberation Sans','font.size':9,'axes.labelsize':9,'axes.titlesize':10,'xtick.labelsize':8.5,'ytick.labelsize':8.5,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','hatch.linewidth':0.65,'axes.linewidth':0.7,'savefig.facecolor':'white'})
INK='#263D4D'; MUTED='#52616C'; SLATE='#758895'; BLUE='#2B6E96'; TEAL='#24776D'; GOLD='#B5863E'; RUST='#A85036'; LIGHT='#E4EBEF'; PALE='#F4F7F9'; WHITE='#FFFFFF'
STAT=['Reported','Held for Document Update','Rejected','Verified']
SHORT={'Reported':'Reported','Held for Document Update':'Held','Rejected':'Rejected','Verified':'Verified'}
C={'Reported':SLATE,'Held for Document Update':GOLD,'Rejected':RUST,'Verified':BLUE}
MARK={'Reported':'o','Held for Document Update':'s','Rejected':'X','Verified':'D'}

def save(fig,name):
    for ext in ['pdf','svg','png']:
        fig.savefig(OUT/f'{name}.{ext}',dpi=350 if ext=='png' else 150)
    plt.close(fig)

def blank(figsize,rect=(0.015,0.025,0.97,0.95)):
    fig=plt.figure(figsize=figsize); ax=fig.add_axes(rect); ax.set_axis_off(); ax.set_xlim(0,1); ax.set_ylim(0,1)
    return fig,ax

def box(ax,x,y,w,h,title,detail='',fill=PALE,edge=LIGHT,fs=9.4):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.005,rounding_size=0.012',fc=fill,ec=edge,lw=0.8))
    ax.text(x+w/2,y+h*(0.66 if detail else .5),title,ha='center',va='center',fontsize=fs,fontweight='bold',color=INK,linespacing=1.13)
    if detail: ax.text(x+w/2,y+h*.28,detail,ha='center',va='center',fontsize=8.1,color=MUTED,linespacing=1.14)

def arrow(ax,a,b,color=SLATE,style='-',rad=0):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=9,lw=1.05,color=color,linestyle=style,connectionstyle=f'arc3,rad={rad}',shrinkA=2,shrinkB=2))

# Figure 1: research design, with independent retrieval and frozen prediction paths.
fig,ax=blank((6.78,3.12))
ax.text(.01,.975,'A   Reconstruct historical registry membership',va='top',color=INK,fontweight='bold',fontsize=10.4)
box(ax,.018,.75,.245,.16,'Dec 2022 snapshot','Earlier disposition')
box(ax,.018,.55,.245,.16,'Nov 2026 snapshot','Later disposition')
box(ax,.355,.62,.25,.20,'Match by erratum ID','6,772 shared IDs')
box(ax,.695,.62,.286,.20,'Compare membership','Entry, exit, status change',fill='#EEF5F8',edge='#B7CEDB')
arrow(ax,(.263,.83),(.355,.73)); arrow(ax,(.263,.63),(.355,.70)); arrow(ax,(.605,.72),(.695,.72),BLUE)
ax.text(.01,.49,'B   Test against an archived publisher page',va='top',color=INK,fontweight='bold',fontsize=10.4)
box(ax,.018,.235,.245,.18,'Jan 2023 + Nov 2026','Two status filters')
box(ax,.355,.235,.25,.18,'Lock predictions','12 + 12 sampled RFCs',fill='#EEF5F8',edge='#B7CEDB')
box(ax,.695,.16,.286,.22,'Compare ID sets','Exact match and\nmembership errors',fill='#EEF6F3',edge='#BBD3C8')
box(ax,.018,.018,.245,.16,'Archived publisher pages','Retrieved after locking',fill='#F1F6F3',edge='#BBD3C8')
box(ax,.355,.018,.25,.16,'Extract displayed IDs','Independent outcome',fill='#F1F6F3',edge='#BBD3C8')
arrow(ax,(.263,.325),(.355,.325),BLUE); arrow(ax,(.605,.325),(.695,.30),BLUE)
arrow(ax,(.263,.10),(.355,.10),TEAL); arrow(ax,(.605,.10),(.695,.22),TEAL)
save(fig,'fig01_historical_design')

# Figure 2: redesign old KPI workflow, distinguishing archives and certificates.
fig,ax=blank((3.24,2.76),(0.015,.015,.97,.97))
box(ax,.035,.78,.93,.19,'Reconstruct the recorded assessment','Original question, response and reference',fs=9.4)
box(ax,.025,.43,.45,.25,'Evidence boundary','What could the\nreviewer establish?',fill='#EEF5F8',edge='#B7CEDB',fs=9.0)
box(ax,.525,.43,.45,.25,'Defect boundary','Did the labels refer\nto the same defect?',fill='#EEF6F3',edge='#BBD3C8',fs=9.0)
arrow(ax,(.5,.78),(.25,.68),BLUE);arrow(ax,(.5,.78),(.75,.68),TEAL)
box(ax,.025,.19,.45,.16,'Inspect evidence','Countermodels or text',fs=8.8)
box(ax,.525,.19,.45,.16,'Inspect targets','Source and rationale',fs=8.8)
arrow(ax,(.25,.43),(.25,.35),BLUE);arrow(ax,(.75,.43),(.75,.35),TEAL)
ax.text(.5,.11,'Report separately',ha='center',va='center',color=INK,fontweight='bold',fontsize=9.2)
ax.text(.5,.035,'Reference applicability  ·  Agreement  ·  Key status',ha='center',va='center',color=MUTED,fontsize=7.9)
arrow(ax,(.25,.19),(.42,.135),BLUE);arrow(ax,(.75,.19),(.58,.135),TEAL)
save(fig,'fig02_kpi_audit')

# Extract exact endpoint transition counts from individual records, check summary.
with (DATA/'errata/panel.csv').open() as f: rows=list(csv.DictReader(f))
rows=[r for r in rows if r['2022'] in STAT and r['2026'] in STAT]
ct=Counter((r['2022'],r['2026']) for r in rows)
summary=json.loads((DATA/'errata/panel_summary.json').read_text())['primary_2022_to_2026']
assert len(rows)==6772 and all(ct[(a,b)]==summary['matrix'].get(a+' -> '+b,0) for a in STAT for b in STAT)
assert sum(n for (a,b),n in ct.items() if a!=b)==607
with (DATA/'transition_matrix.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['December 2022 / November 2026']+STAT);w.writerows([[a]+[ct[a,b] for b in STAT] for a in STAT])
# Figure 3: alluvial with separate denominators; direct labels; preserve true widths within each panel.
def ribbon(ax,x0,x1,lo0,hi0,lo1,hi1,color,alpha=.45):
    xm=x0+(x1-x0)*.5
    verts=[(x0,lo0),(xm,lo0),(xm,lo1),(x1,lo1),(x1,hi1),(xm,hi1),(xm,hi0),(x0,hi0),(x0,lo0)]
    codes=[MPath.MOVETO,MPath.CURVE4,MPath.CURVE4,MPath.CURVE4,MPath.LINETO,MPath.CURVE4,MPath.CURVE4,MPath.CURVE4,MPath.CLOSEPOLY]
    ax.add_patch(PathPatch(MPath(verts,codes),fc=color,ec='none',alpha=alpha))

def flow_panel(ax,flows,left,right,title,subtitle,footer):
    ax.set_xlim(0,1); ax.set_ylim(0,1);ax.axis('off')
    ax.text(.0,.99,title,ha='left',va='top',fontweight='bold',color=INK,fontsize=10.4)
    ax.text(.0,.92,subtitle,ha='left',va='top',color=MUTED,fontsize=8.5)
    ax.text(.06,.83,'Dec 2022',ha='left',color=MUTED,fontsize=8.6,fontweight='bold')
    ax.text(.70,.83,'Nov 2026',ha='left',color=MUTED,fontsize=8.6,fontweight='bold')
    total=sum(flows.values()); gap=.045; height=.60; top=.79; scale=(height-(max(len(left),len(right))-1)*gap)/total
    def layout(nodes,side):
        y=top; pos={}
        for k in nodes:
            n=sum(v for (a,b),v in flows.items() if (a if side==0 else b)==k)
            pos[k]=[y-n*scale,y,n];y-=n*scale+gap
        return pos
    L=layout(left,0);R=layout(right,1);lp={k:v[1] for k,v in L.items()};rp={k:v[1] for k,v in R.items()}
    for a in left:
        for b in right:
            n=flows.get((a,b),0)
            if not n:continue
            h=n*scale;lhi=lp[a];rhi=rp[b];lp[a]-=h;rp[b]-=h
            ribbon(ax,.34,.69,lhi-h,lhi,rhi-h,rhi,C[b],.50)
    for k,(lo,hi,n) in L.items():
        ax.add_patch(Rectangle((.30,lo),.04,hi-lo,fc=C[k],ec='none'))
        ax.text(.28,(lo+hi)/2,SHORT[k]+'\n'+f'{n:,}',ha='right',va='center',fontsize=8.5,color=INK,linespacing=1.05)
    for k,(lo,hi,n) in R.items():
        ax.add_patch(Rectangle((.69,lo),.04,hi-lo,fc=C[k],ec='none'))
        ax.text(.75,(lo+hi)/2,SHORT[k]+'\n'+f'{n:,}',ha='left',va='center',fontsize=8.5,color=INK,linespacing=1.05)
    ax.text(.0,.045,footer,ha='left',va='bottom',color=MUTED,fontsize=8.2,linespacing=1.2)
fig=plt.figure(figsize=(6.78,3.07)); a=fig.add_axes([.015,.04,.475,.94]);b=fig.add_axes([.52,.04,.475,.94]);
reported={(x,y):n for (x,y),n in ct.items() if x=='Reported' and n}; processed={(x,y):n for (x,y),n in ct.items() if x!='Reported' and x!=y and n}
assert sum(reported.values())==976 and sum(processed.values())==6
flow_panel(a,reported,['Reported'],STAT,'A   Initially pending filings','976 records · 601 changed status','375 remained Reported.')
flow_panel(b,processed,['Held for Document Update','Rejected','Verified'],['Verified','Rejected'],'B   Changed processed filings','6 of 5,796 previously processed','5,790 retained their status.\nPanel B uses its own scale (6 records).')
save(fig,'fig03_errata_status_flows')

# Figure 4: all observed multi-transition paths, grouped only if complete timestamp sequences match.
with (DATA/'errata/aggregate_history_events.csv').open() as f: events=list(csv.DictReader(f))
hist=json.loads((DATA/'errata/aggregate_history_summary.json').read_text())
mult=hist['multiple_transitions'];assert len(mult)==8
seqs={}
for i,states in mult.items():
    es=[e for e in events if e['id']==i]
    es.sort(key=lambda x:x['commit_time_utc'])
    assert [es[0]['old']]+[e['new'] for e in es]==states
    seqs[i]=(states,[e['commit_time_utc'] for e in es])
with (DATA/'multi_transition_paths.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['erratum_id','event_order','status','capture_utc'])
    for i,(st,ds) in seqs.items():
        for j,(s,d) in enumerate(zip(st,[hist['first_utc']]+ds)):w.writerow([i,j,s,d])
assert all(seqs[i]==seqs['150'] for i in ['3264','3809','5766'])
fig,ax=blank((6.78,3.75),(0.01,.02,.98,.96));
ax.text(.012,.985,'Observed status paths for all eight errata with multiple changes',va='top',fontsize=10.5,fontweight='bold',color=INK)
ax.text(.012,.92,'Positions encode capture order, not elapsed time.',va='top',fontsize=8.7,color=MUTED)
xs=[.30,.505,.71,.915]
for x,lab in zip(xs,['Dec 2022','First change','Second change','Third change']):ax.text(x,.83,lab,ha='center',va='center',color=MUTED,fontsize=8.7,fontweight='bold')
ordered=[('150, 3264,\n3809, 5766','150'),('4550','4550'),('6090','6090'),('7102','7102'),('7272','7272')]
for idx,((label,i),y) in enumerate(zip(ordered,[.727,.569,.411,.253,.095])):
    st,ds=seqs[i];ax.text(.012,y,label,ha='left',va='center',fontsize=9.3,fontweight='bold',color=INK)
    if i in ['6090','7272']:
        # light row field highlights hidden intermediate decisions without relying on hue.
        ax.add_patch(Rectangle((.223,y-.060),.765,.120,fc='#F3F6F8',ec='none',zorder=0))
    ax.plot(xs[:len(st)],[y]*len(st),color='#A5B1B9',lw=1.25,linestyle=(0,(3,2)),zorder=1)
    for j,s in enumerate(st):
        ax.scatter([xs[j]],[y],s=47,marker=MARK[s],color=C[s],edgecolor='white',linewidth=.65,zorder=3)
        ax.text(xs[j],y+.029,SHORT[s],ha='center',va='bottom',fontsize=8.25,color=INK,fontweight='bold')
        if j:
            d=datetime.fromisoformat(ds[j-1].replace('Z','+00:00'));ax.text(xs[j],y-.026,d.strftime('%d %b %Y').lstrip('0'),ha='center',va='top',fontsize=7.8,color=MUTED)
save(fig,'fig04_observed_status_paths')

# Figure 5: actual observed publisher membership, compared with locked predictions.
res=json.loads((DATA/'publisher_holdout/results.json').read_text());pred=json.loads((DATA/'publisher_holdout/predictions.json').read_text());lock=json.loads((DATA/'publisher_holdout/PREDICTION_LOCK.json').read_text());
assert hashlib.sha256((DATA/'publisher_holdout/predictions.json').read_bytes()).hexdigest()==lock['sha256']
lookup={c['rfc']:c for c in res['cases']};records={}
with (DATA/'publisher_page_counts.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['rfc','stratum','available','historical_ids','observed_displayed','dated_predicted','current_predicted','dated_errors','current_false_inclusions','current_false_exclusions'])
    for stratum in ['changed','agreement']:
        records[stratum]=[]
        for p in pred['selection'][stratum]:
            c=lookup[p['rfc']];assert c['stratum']==stratum and p['universe']==c['universe'] and p['january']==c['january'] and p['november_on_january']==c['november_on_january']
            if c['available']:
                observed=set(c['observed_on_january']);dated=set(p['january']);later=set(p['november_on_january']);assert observed==dated and not(observed-later)
                n=len(observed);extra=len(later-observed);miss=len(observed-later);de=len(observed^dated)
                w.writerow([p['rfc'],stratum,True,len(p['universe']),n,len(dated),len(later),de,extra,miss]);records[stratum].append((p['rfc'],n,extra))
            else:
                w.writerow([p['rfc'],stratum,False,len(p['universe']),'',len(p['january']),len(p['november_on_january']),'','','']);records[stratum].append((p['rfc'],None,None))
assert sum(v[1] for v in records['changed'])==50 and sum(v[2] for v in records['changed'])==19
assert sum(v[1] for v in records['agreement'] if v[1] is not None)==16 and sum(v[1] is None for v in records['agreement'])==1
fig=plt.figure(figsize=(6.78,4.25));axes=[fig.add_axes([.105,.17,.375,.70]),fig.add_axes([.605,.17,.375,.70])]
for ax,stratum,title,sub in zip(axes,['changed','agreement'],['A   Disagreement pages','B   Agreement controls'],['12/12 exact: dated · 0/12: current','11/11 exact for both filters']):
    arr=records[stratum];y=list(range(len(arr)));ax.set_ylim(-.62,len(arr)-.38);ax.invert_yaxis();ax.set_xlim(0,15.7)
    ax.set_yticks(y,[str(a[0]) for a in arr]);ax.tick_params(axis='y',length=0,pad=4);ax.tick_params(axis='x',colors=MUTED,length=3)
    ax.set_xticks([0,3,6,9,12,15]);ax.set_xlabel('Number of corrections',color=INK,labelpad=4)
    ax.set_axisbelow(True);ax.xaxis.grid(True,lw=.45,color=LIGHT)
    for s in ['top','right','left']:ax.spines[s].set_visible(False)
    ax.spines['bottom'].set_color('#9AAAB5')
    ax.text(0,1.135,title,transform=ax.transAxes,fontsize=10.4,fontweight='bold',color=INK,va='top')
    ax.text(0,1.05,sub,transform=ax.transAxes,fontsize=8.4,color=MUTED,va='top')
    for yi,(_,n,e) in enumerate(arr):
        if n is None:
            ax.text(.15,yi,'No qualifying capture',color=MUTED,fontsize=8,va='center',fontstyle='italic');continue
        ax.barh(yi,n,height=.61,color=BLUE,edgecolor='none',zorder=2)
        if e:
            ax.barh(yi,e,left=n,height=.61,facecolor='#E5BA91',edgecolor=RUST,hatch='///',linewidth=.5,zorder=2)
            ax.text(n+e+.17,yi,f'+{e}',va='center',ha='left',fontsize=8.3,color=RUST,fontweight='bold')
        elif n>=1: ax.text(n+.17,yi,str(n),va='center',ha='left',fontsize=8.1,color=MUTED)
fig.text(.02,.91,'RFC',fontsize=8.5,color=MUTED,fontweight='bold');fig.text(.52,.91,'RFC',fontsize=8.5,color=MUTED,fontweight='bold')
handles=[Rectangle((0,0),1,1,fc=BLUE,ec='none',label='Displayed IDs = dated prediction'),Rectangle((0,0),1,1,fc='#E5BA91',ec=RUST,hatch='///',label='Additional IDs from current filter')]
fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.015),ncol=2,frameon=False,fontsize=8.5,columnspacing=1.5,handlelength=1.5)
save(fig,'fig05_publisher_page_comparison')
print('Rendered five figures; verified transition matrix, paths and locked page predictions.')
