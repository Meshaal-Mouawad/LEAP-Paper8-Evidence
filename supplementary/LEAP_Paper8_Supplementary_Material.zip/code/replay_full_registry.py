#!/usr/bin/env python3
"""W8 retrospective full-registry selection audit. Uses only frozen R35 input.
Usage: python3 code/replay_full_registry.py data/source_records.zip OUTPUT_DIR
Historical snapshots are used only as scoring references, not to select current IDs.
No fresh collection, prospective validation, or independent human adjudication.
"""
import csv, datetime as dt, gzip, hashlib, io, json, re, sys, zipfile
from collections import Counter
from pathlib import Path
ROOT='LEAP_Paper8_R35_Research/errata/'
V='Verified'
CHECKPOINTS=[('2022-12-31','mirror_2022.json.gz'),('2023-01-29','wayback_20230129.json.gz'),('2023-12-31','mirror_2023.json.gz'),('2024-12-31','mirror_2024.json.gz'),('2025-12-31','mirror_2025.json.gz')]
def sha(b): return hashlib.sha256(b).hexdigest()
def date(s):
    try: return dt.datetime.fromisoformat(s).date()
    except (ValueError,TypeError): return None
def norm(s): return s.replace('\r\n','\n').replace('\r','\n') if isinstance(s,str) else s
def rfc(s): return int(re.fullmatch(r'RFC0*(\d+)',s.strip(),re.I)[1])
def text_same(a,b): return rfc(a['doc-id'])==rfc(b['doc-id']) and all(norm(a[k])==norm(b[k]) for k in ('orig_text','correct_text'))
def select(L,cutoff):
    """Current-only predictions. Historical IDs are intentionally absent from signature."""
    verified={i for i,x in L.items() if x['errata_status_code']==V}
    f={i for i in verified if (d:=date(L[i].get('submit_date'))) is not None and d<=cutoff}
    u={i for i in verified if (d:=date(L[i].get('update_date'))) is not None and d<=cutoff}
    return {'filing':f,'update':u,'both':f&u}, {'filing_invalid':sum(date(L[i].get('submit_date')) is None for i in verified),'update_invalid':sum(date(L[i].get('update_date')) is None for i in verified)}
def writecsv(p,rs):
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
def score(s,t): return dict(selected=len(s),true_positive=len(s&t),added=len(s-t),omitted=len(t-s),exact=int(s==t))
def main(archive,out):
    out.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        def j(n): return json.loads(z.read(ROOT+n))
        meta={f"mirror_{x['year']}.json.gz":x for x in j('mirrors.json')};meta['registry.json.gz']=j('source.json');meta['wayback_20230129.json.gz']=j('wayback.json')
        hashes={}
        def load(n):
            raw=gzip.decompress(z.read(ROOT+n)); hashes[n]=sha(raw); assert hashes[n]==meta[n]['sha256'],n
            rs=json.loads(raw); idx={int(x['errata_id']):x for x in rs};assert len(idx)==len(rs)
            return idx
        later=load('registry.json.gz'); rows=[]; errors=[]; missing=[]; stable_rows=[]; ledger=[]; extras=[]
        for stamp,n in CHECKPOINTS:
            cutoff=dt.date.fromisoformat(stamp)
            # Lock selection before loading the target snapshot. This establishes input separation, not prospective timing.
            preds,invalid=select(later,cutoff)
            old=load(n); truth={i for i,x in old.items() if x['errata_status_code']==V}; shared=set(old)&set(later)
            stable={i for i in shared if text_same(old[i],later[i])}; missing_ids=set(old)-set(later)
            for i in sorted(missing_ids): missing.append(dict(cutoff=stamp,id=i,earlier_status=old[i]['errata_status_code'],rfc=rfc(old[i]['doc-id'])))
            row=dict(cutoff=stamp,earlier_records=len(old),shared_ids=len(shared),earlier_only=len(missing_ids),earlier_verified=len(truth),earlier_verified_missing_later=len(truth-set(later)),stable_text_shared_ids=len(stable),**invalid)
            stable_row=dict(cutoff=stamp,stable_shared_ids=len(stable),stable_earlier_verified=len(truth&stable))
            for name,p in preds.items():
                for k,v in score(p,truth).items(): row[f'{name}_{k}']=v
                row[f'{name}_outside_earlier_ids']=len(p-set(old))
                for k,v in score(p&stable,truth&stable).items(): stable_row[f'{name}_{k}']=v
                for i in sorted(p^truth):
                    a=old.get(i,{}); b=later.get(i,{})
                    errors.append(dict(cutoff=stamp,selector=name,id=i,error='extra' if i in p else 'omitted',in_earlier=int(i in old),in_later=int(i in later),earlier_status=a.get('errata_status_code','ABSENT'),later_status=b.get('errata_status_code','ABSENT'),later_submit=b.get('submit_date',''),later_update=b.get('update_date',''),same_rfc_and_text=int(i in stable)))
                for i in sorted(p-set(old)):
                    b=later[i];extras.append(dict(cutoff=stamp,selector=name,id=i,rfc=rfc(b['doc-id']),current_filing_date=b.get('submit_date'),current_update_date=b.get('update_date')))
            for i in sorted(set(old)|set(later)):
                ledger.append(dict(cutoff=stamp,id=i,earlier_present=int(i in old),later_present=int(i in later),earlier_verified=int(i in truth),filing=int(i in preds['filing']),update=int(i in preds['update']),both=int(i in preds['both']),same_rfc_and_text=int(i in stable)))
            rows.append(row);stable_rows.append(stable_row)
        assert len(later)==8190
        assert [(r['earlier_records'],r['earlier_only'],r['earlier_verified_missing_later'],r['filing_added'],r['filing_omitted'],r['update_added'],r['update_omitted'],r['both_added'],r['both_omitted']) for r in rows]==[(6781,9,0,294,1,0,7,0,7),(6800,6,0,300,1,0,6,0,6),(7039,6,0,298,1,0,7,0,7),(7392,1,0,102,0,0,3,0,3),(7764,1,0,42,5,0,6,0,6)]
        assert all(r['filing_invalid']==r['update_invalid']==0 for r in rows)
        assert all(r['update_selected']==r['both_selected'] for r in rows)
        assert {(r['cutoff'],r['id']) for r in extras}=={('2023-01-29',7324),('2023-12-31',7744)}
        assert (stable_rows[0]['stable_shared_ids'],stable_rows[0]['filing_added'],stable_rows[0]['filing_omitted'],stable_rows[0]['update_omitted'])==(6511,260,1,4)
        for name,data in [('full_registry_comparison.csv',rows),('stable_text_comparison.csv',stable_rows),('selection_errors.csv',errors),('missing_earlier_records.csv',missing),('outside_earlier_ids.csv',extras),('full_id_predictions.csv',ledger)]:writecsv(out/name,data)
        report={'scope':'Retrospective sensitivity analysis; no earlier ID input to current-only selectors; frozen snapshots are outcome references','archive_sha256':sha(archive.read_bytes()),'snapshot_sha256':hashes,'current_registry_records':len(later),'checkpoints':rows,'stable_text_checkpoints':stable_rows,'outside_earlier_ids':extras,'missing_earlier_verified_total_across_checkpoints':sum(r['earlier_verified_missing_later'] for r in rows),'prediction_ledger_rows':len(ledger)}
        (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
        print('PASS: 5 historical checkpoints, verified source hashes, 3 current-only selectors; '+str(len(ledger))+' ID-by-checkpoint predictions')
if __name__=='__main__': main(Path(sys.argv[1]),Path(sys.argv[2]))
