"""Recalculate the central novelty evidence from the frozen R35 ZIP.
No network requests; no dependence on the original R35 analysis functions.
Usage: python3 code/replay_historical_panel.py data/source_records.zip
"""
import collections as C, datetime as DT, gzip, hashlib, json, re, sys, zipfile
from html.parser import HTMLParser
from pathlib import Path
class IDs(HTMLParser):
    def __init__(self): super().__init__(); self.ids=set()
    def handle_starttag(self,tag,attrs):
        m=re.fullmatch(r'eid(\d+)',dict(attrs).get('id','') or '',re.I)
        if m:self.ids.add(int(m.group(1)))
def sha(x):return hashlib.sha256(x).hexdigest()
def status(x):return x['errata_status_code']
def rfc(x):return int(re.fullmatch(r'RFC0*(\d+)',x['doc-id'].strip(),re.I)[1])
def norm(x):return x.replace('\r\n','\n').replace('\r','\n') if isinstance(x,str) else x
with zipfile.ZipFile(sys.argv[1]) as z:
    root='LEAP_Paper8_R35_Research/'
    def read(p):return z.read(root+p)
    def load(p):return json.loads(read(p))
    def snap(p):
        raw=gzip.decompress(read(p)); rows=json.loads(raw); ix={int(x['errata_id']):x for x in rows}; assert len(ix)==len(rows);return raw,ix
    raw_a,a=snap('errata/mirror_2022.json.gz');raw_b,b=snap('errata/registry.json.gz');raw_j,j=snap('errata/wayback_20230129.json.gz');raw_m,m=snap('errata/tma_reconstruction/march16_2023.json.gz')
    shared=set(a)&set(b); assert len(shared)==6772
    matrix=C.Counter((status(a[i]),status(b[i])) for i in shared)
    av={i for i in shared if status(a[i])=='Verified'}; bv={i for i in shared if status(b[i])=='Verified'}
    additions=bv-av; omissions=av-bv
    changed={i for i in shared if status(a[i])!=status(b[i])};processed={i for i in shared if status(a[i])!='Reported'};rev=changed&processed
    assert (len(a),len(b),len(shared),len(changed),len(processed),len(rev),len(av),len(bv),len(additions),len(omissions))==(6781,8190,6772,607,5796,6,2875,3168,294,1)
    for i in rev:
        assert rfc(a[i])==rfc(b[i]) and all(norm(a[i][k])==norm(b[i][k]) for k in ['orig_text','correct_text'])
        assert status(j[i])==status(a[i])
    assert rev=={150,3264,3809,4550,5766,6751}
    def window(ix):
        out={}
        for i,x in ix.items():
            try: filed=DT.date.fromisoformat(x['submit_date'])
            except (TypeError,ValueError): continue
            if DT.date(2001,1,1)<=filed<=DT.date(2022,12,31):out[i]=x
        return out
    ma,mb=window(m),window(b); ms=set(ma)&set(mb); va={i for i in ms if status(ma[i])=='Verified'};vb={i for i in ms if status(mb[i])=='Verified'}
    assert (len(ma),len(mb),len(ms),len(vb-va),len(va-vb))==(6759,6758,6754,283,1)
    pred=load('publisher_holdout/predictions.json'); lock=load('publisher_holdout/PREDICTION_LOCK.json'); freeze=DT.datetime.fromisoformat(lock['utc']);assert sha(read('publisher_holdout/predictions.json'))==lock['sha256'];assert sha(read('publisher_holdout/PROTOCOL.md'))==lock['protocol_sha256'];assert pred['january_sha256']==sha(raw_j) and pred['november_sha256']==sha(raw_b)
    groups=C.defaultdict(set)
    for i,x in j.items():groups[rfc(x)].add(i)
    strata=C.defaultdict(list)
    for n,ids in groups.items():
        if n in {4271,4384,8913} or not ids<=set(b):continue
        old={i for i in ids if status(j[i])=='Verified'};late={i for i in ids if status(b[i])=='Verified'}
        if not old:continue
        strata['changed' if old!=late else 'agreement'].append(dict(rfc=n,rank=sha(f'LEAP-R35-inline-2023-01-29|{n}'.encode()),universe=sorted(ids),january=sorted(old),november_on_january=sorted(late)))
    assert {k:len(v) for k,v in strata.items()}==pred['eligible']=={'changed':100,'agreement':1331}
    assert {k:sorted(v,key=lambda x:x['rank'])[:12] for k,v in strata.items()}==pred['selection']
    summaries={};rows=[];num_attempts=0;max_displacement=0
    for k,rs in pred['selection'].items():
        counter=C.Counter(selected=len(rs))
        for p in rs:
            n=p['rfc'];f=load(f'publisher_holdout/fetch_logs/{n}.json')
            for at in f['attempts']:
                raw=gzip.decompress(read('publisher_holdout/'+at['path']));assert sha(raw)==at['sha256'] and len(raw)==at['byte_count'];assert DT.datetime.fromisoformat(at['utc'])>freeze;num_attempts+=1
            if not f['available']:
                rows.append(dict(rfc=n,stratum=k,available=False));continue
            raw=gzip.decompress(read('publisher_holdout/'+f['path']));assert sha(raw)==f['sha256']; h=raw.decode('utf-8');parser=IDs();parser.feed(h)
            title=re.search(r'<title>\s*RFC\s*(\d+)\s*</title>',h,re.I);header=re.search(r'The following\s+[\'\"]Verified[\'\"] errata have been incorporated in this document:\s*(.*?)</div>',h,re.I|re.S)
            assert title and int(title[1])==n and header and 'purely informative rendering' in h.lower()
            visible={int(i) for i in re.findall(r'>\s*EID\s+(\d+)\s*</a>\s*\(Verified\)',h,re.I)}; links={int(i) for i in re.findall(r'href=[\'\"]#(?:btn_|eid)(\d+)[\'\"]',header[1],re.I)};assert parser.ids==visible==links
            stamp=DT.datetime.strptime(f['stamp'],'%Y%m%d%H%M%S');distance=abs((stamp-DT.datetime(2023,1,29,14,20,48)).total_seconds());assert distance<=7*86400;max_displacement=max(max_displacement,distance)
            obs=parser.ids&set(p['universe']);d=set(p['january']);c=set(p['november_on_january']);counter.update(available=1,observed=len(obs),historical_ids=len(p['universe']),dated_exact=int(d==obs),current_exact=int(c==obs),dated_errors=len(d^obs),current_errors=len(c^obs),current_additions=len(c-obs),current_omissions=len(obs-c));rows.append(dict(rfc=n,stratum=k,available=True,observed=sorted(obs),dated=sorted(d),current=sorted(c),current_additions=sorted(c-obs),current_omissions=sorted(obs-c),source_sha256=sha(raw)))
        summaries[k]=dict(counter)
    assert summaries['changed']==dict(selected=12,available=12,observed=50,historical_ids=155,dated_exact=12,current_exact=0,dated_errors=0,current_errors=19,current_additions=19,current_omissions=0)
    assert summaries['agreement']==dict(selected=12,available=11,observed=16,historical_ids=35,dated_exact=11,current_exact=11,dated_errors=0,current_errors=0,current_additions=0,current_omissions=0)
    out=dict(scope='Independent implementation replay of frozen inputs; no live source retrieval or external peer review',archive_sha256=sha(Path(sys.argv[1]).read_bytes()),matrix={f'{k[0]} -> {k[1]}':v for k,v in sorted(matrix.items())},matched=len(shared),changed=len(changed),old_only=len(set(a)-set(b)),new_only=len(set(b)-set(a)),historical_verified=len(av),current_verified=len(bv),additions=len(additions),omissions=len(omissions),addition_fraction=len(additions)/len(bv),addition_origins=dict(C.Counter(status(a[i]) for i in additions)),processed_changes=sorted(rev),processed_unchanged_text_verified=True,processed_prior_statuses_confirmed_in_january=True,march_reconstruction=dict(earlier=len(ma),later=len(mb),shared=len(ms),additions=len(vb-va),omissions=len(va-vb)),holdout=summaries,archive_attempts_verified=num_attempts,max_capture_displacement_hours=max_displacement/3600,cases=rows)
    print(json.dumps(out,indent=2))
