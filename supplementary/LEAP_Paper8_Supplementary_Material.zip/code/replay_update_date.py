"""Retrospective update-date comparison using original frozen R35 evidence.
Usage: python3 code/replay_update_date.py data/source_records.zip OUTPUT_DIR
No live retrieval. Original held-out sample and predictions are unchanged.
"""
import csv, datetime as dt, gzip, hashlib, io, json, re, sys, zipfile
from collections import Counter, defaultdict
from html.parser import HTMLParser
from pathlib import Path

ROOT='LEAP_Paper8_R35_Research/'
VERIFIED='Verified'
def digest(raw): return hashlib.sha256(raw).hexdigest()
def calendar_date(value):
    try: return dt.datetime.fromisoformat(value).date()
    except (TypeError, ValueError): return None

def dump_csv(path, rows):
    assert rows
    with path.open('w', newline='', encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def norm(value):
    return value.replace('\r\n','\n').replace('\r','\n') if isinstance(value,str) else value

def rfc(x):return int(re.fullmatch(r'RFC0*(\d+)',x['doc-id'].strip(),re.I)[1])

def select(later, ids, cutoff):
    current={i for i in ids if later[i]['errata_status_code']==VERIFIED}
    invalid={i for i in current if calendar_date(later[i].get('update_date')) is None}
    dated={i for i in current-invalid if calendar_date(later[i]['update_date'])<=cutoff}
    return current,dated,invalid

def score(pred,truth):
    return {'additions':len(pred-truth),'omissions':len(truth-pred),'exact':int(pred==truth)}

class Extract(HTMLParser):
    def __init__(self):super().__init__();self.ids=set()
    def handle_starttag(self,tag,attrs):
        match=re.fullmatch(r'eid(\d+)',dict(attrs).get('id','') or '',re.I)
        if match:self.ids.add(int(match[1]))

def html_ids(raw):
    text=raw.decode('utf-8');p=Extract();p.feed(text)
    visible={int(i) for i in re.findall(r'>\s*EID\s+(\d+)\s*</a>\s*\(Verified\)',text,re.I)}
    header=re.search(r'The following\s+[\'\"]Verified[\'\"] errata have been incorporated in this document:\s*(.*?)</div>',text,re.I|re.S)
    assert header and 'purely informative rendering' in text.lower()
    linked={int(i) for i in re.findall(r'href=[\'\"]#(?:btn_|eid)(\d+)[\'\"]',header[1],re.I)}
    assert p.ids==visible==linked
    return p.ids

def main(archive,out):
    out.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        def read(name):return z.read(ROOT+name)
        def load(name):return json.loads(read(name))
        hashes={}
        def snapshot(name,expected):
            raw=gzip.decompress(read('errata/'+name));hashes[name]=digest(raw);assert hashes[name]==expected
            rows=json.loads(raw);index={int(x['errata_id']):x for x in rows};assert len(index)==len(rows)
            return index
        mirrors={int(x['year']):x for x in load('errata/mirrors.json')}
        endpoints=[(f'{year}-12-31',f'mirror_{year}.json.gz',mirrors[year]['sha256']) for year in [2022,2023,2024,2025]]
        endpoints.insert(1,('2023-01-29','wayback_20230129.json.gz',load('errata/wayback.json')['sha256']))
        later=snapshot('registry.json.gz',load('errata/source.json')['sha256'])
        years={date:snapshot(name,h) for date,name,h in endpoints}
        rows=[];ledger=[];omitted=[]
        history=list(csv.DictReader(io.StringIO(read('errata/aggregate_history_events.csv').decode())))
        changes=Counter(int(x['id']) for x in history)
        for date,old in years.items():
            U=set(old)&set(later);truth={i for i in U if old[i]['errata_status_code']==VERIFIED}
            current,cut,invalid=select(later,U,dt.date.fromisoformat(date))
            s1,s2=score(current,truth),score(cut,truth)
            rows.append(dict(cutoff=date,shared=len(U),historical_verified=len(truth),current_verified=len(current),cutoff_verified=len(cut),current_added=s1['additions'],current_omitted=s1['omissions'],cutoff_added=s2['additions'],cutoff_omitted=s2['omissions'],invalid_update_fields=len(invalid),omitted_still_verified=len((truth-cut)&current),omitted_no_longer_verified=len(truth-current)))
            for i in sorted(U):
                ledger.append(dict(cutoff=date,erratum_id=i,earlier_status=old[i]['errata_status_code'],later_status=later[i]['errata_status_code'],later_update_date=later[i].get('update_date') or '',historical_verified=int(i in truth),current_verified=int(i in current),cutoff_verified=int(i in cut)))
            if date=='2022-12-31':
                for i in sorted(truth-cut):
                    a,b=old[i],later[i]
                    fields=[k for k in ['section','orig_text','correct_text','notes','submit_date'] if norm(a.get(k))!=norm(b.get(k))]
                    omitted.append(dict(erratum_id=i,rfc=rfc(a),historical_status=a['errata_status_code'],current_status=b['errata_status_code'],earlier_update_date=a['update_date'],later_update_date=b['update_date'],same_rfc_number=int(rfc(a)==rfc(b)),same_original_text=int(norm(a['orig_text'])==norm(b['orig_text'])),same_correction_text=int(norm(a['correct_text'])==norm(b['correct_text'])),changed_content_fields=';'.join(fields),observed_status_transitions=changes[i],observed_checkpoint_statuses=';'.join(f'{d}:{s[i]["errata_status_code"]}' for d,s in years.items() if i in s)))
        assert [(r['shared'],r['current_added'],r['current_omitted'],r['cutoff_added'],r['cutoff_omitted'],r['invalid_update_fields']) for r in rows]==[(6772,294,1,0,7,0),(6794,299,1,0,6,0),(7033,297,1,0,7,0),(7391,102,0,0,3,0),(7763,42,5,0,6,0)]
        stable=[r for r in omitted if r['current_status']==VERIFIED]
        assert len(stable)==6 and all(r['observed_status_transitions']==0 for r in stable)
        same_text=[r['erratum_id'] for r in stable if r['same_original_text'] and r['same_correction_text']]
        assert same_text==[6156,6679,6911]
        assert {r['erratum_id'] for r in omitted}=={524,1073,6156,6184,6679,6751,6911}
        pred=load('publisher_holdout/predictions.json');lock=load('publisher_holdout/PREDICTION_LOCK.json');assert digest(read('publisher_holdout/predictions.json'))==lock['sha256']
        assert digest(read('publisher_holdout/PROTOCOL.md'))==lock['protocol_sha256']
        assert pred['january_sha256']==hashes['wayback_20230129.json.gz'] and pred['november_sha256']==hashes['registry.json.gz']
        pages=[];sums=defaultdict(Counter);jan=years['2023-01-29']
        for stratum,ps in pred['selection'].items():
            for p in ps:
                n=p['rfc'];U=set(p['universe']);f=load(f'publisher_holdout/fetch_logs/{n}.json')
                truth_dated={i for i in U if jan[i]['errata_status_code']==VERIFIED}
                current,cut,invalid=select(later,U,dt.date(2023,1,29))
                assert truth_dated==set(p['january']) and current==set(p['november_on_january'])
                assert not invalid
                row=dict(rfc=n,stratum=stratum,available=bool(f['available']),observed_ids='',historical_ids=';'.join(map(str,sorted(U))),dated_prediction=';'.join(map(str,sorted(truth_dated))),current_prediction=';'.join(map(str,sorted(current))),cutoff_prediction=';'.join(map(str,sorted(cut))),dated_errors='',current_errors='',cutoff_errors='',cutoff_additions='',cutoff_omissions='',cutoff_exact='',source_sha256='')
                sums[stratum]['selected']+=1
                if f['available']:
                    raw=gzip.decompress(read('publisher_holdout/'+f['path']));assert digest(raw)==f['sha256']
                    assert re.search(r'<title>\s*RFC\s*'+str(n)+r'\s*</title>',raw.decode('utf-8'),re.I)
                    obs=html_ids(raw)&U;sd,sc,st=(score(x,obs) for x in [truth_dated,current,cut])
                    sums[stratum].update(available=1,dated_exact=sd['exact'],current_exact=sc['exact'],cutoff_exact=st['exact'],cutoff_additions=st['additions'],cutoff_omissions=st['omissions'])
                    row.update(observed_ids=';'.join(map(str,sorted(obs))),dated_errors=len(truth_dated^obs),current_errors=len(current^obs),cutoff_errors=len(cut^obs),cutoff_additions=st['additions'],cutoff_omissions=st['omissions'],cutoff_exact=st['exact'],source_sha256=digest(raw))
                pages.append(row)
        assert dict(sums['changed'])==dict(selected=12,available=12,dated_exact=12,current_exact=0,cutoff_exact=12,cutoff_additions=0,cutoff_omissions=0)
        assert dict(sums['agreement'])==dict(selected=12,available=11,dated_exact=11,current_exact=11,cutoff_exact=11,cutoff_additions=0,cutoff_omissions=0)
        # A known diagnostic case excluded by the original holdout protocol.
        info=load('errata/inline_sources.json');examples=[]
        for stamp in ['20230130025836','20231231130402']:
            key='8913_'+stamp;raw=gzip.decompress(read('errata/inline_'+key+'.html.gz'));assert digest(raw)==info[key]['sha256']
            assert 6751 in html_ids(raw)
            examples.append(dict(rfc=8913,erratum_id=6751,archive_url=info[key]['url'],sha256=digest(raw),observed_verified=True,later_status=later[6751]['errata_status_code'],current_selects=False,cutoff_selects=False))
        dump_csv(out/'checkpoint_comparison.csv',rows);dump_csv(out/'per_id_predictions.csv',ledger);dump_csv(out/'december_omissions.csv',omitted);dump_csv(out/'publisher_page_comparison.csv',pages)
        report=dict(scope='Post-hoc comparison on frozen original records and archived HTML; no new held-out acquisition or human judgments',archive_sha256=digest(archive.read_bytes()),source_snapshot_sha256=hashes,original_prediction_lock_sha256=lock['sha256'],checkpoints=rows,december_omissions=omitted,still_verified_omissions_with_unchanged_text=same_text,publisher_pages={k:dict(v) for k,v in sums.items()},diagnostic_known_case=examples,per_id_rows=len(ledger))
        (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps({k:v for k,v in report.items() if k not in ['december_omissions','source_snapshot_sha256','diagnostic_known_case']},indent=2))
if __name__=='__main__': main(Path(sys.argv[1]),Path(sys.argv[2]))
