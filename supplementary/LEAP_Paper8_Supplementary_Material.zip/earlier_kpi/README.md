# Supporting KPI archival audits

These are the curated analytical records and executable witnesses from the earlier dataset associated with DOI 10.7910/DVN/DC2FOK. The 27 main trials are recorded as synthetic; the complete-source proposed key was not used for original grading. The second archive is a separate 28-dossier study with an 18-case curated subset. The original provenance statement is retained in `metadata/Provenance.md`. Controlled raw assessment records are not included.

Run `python3 -B code/reproduce_curated.py` from this directory.
