# Data dictionary

## Units and reference sets

- `erratum_id` or `id`: stable numeric erratum identifier; not a document count.
- `rfc`: numeric RFC identifier, normalized independently of leading zeros.
- `cutoff`: historical capture calendar day; not a presumed approval timestamp.
- `earlier_status`, `historical_status`, `current_status`, `later_status`: the recorded disposition at the specified capture. Values include Reported, Verified, Rejected and Held for Document Update.
- Historical Verified set: identifiers with Verified status in the earlier capture. For page-level tests, the observed set is the set of Verified correction IDs actually displayed in the captured publisher page.
- `status`, `current_verified`, `current_prediction`: latest Verified status, with the candidate universe defined in the corresponding experiment.
- `filing`: latest Verified status with recorded submission date on or before the cutoff.
- `update`, `cutoff_verified`, `cutoff_prediction`: latest Verified status with recorded update date on or before the cutoff.
- `both`: conjunction of filing-date and update-date rules.
- `locked_dated`: original historical-status prediction fixed before retrieving publisher-page outcomes.
- `additions` / `added` / `extra`: selected IDs absent from the observed reference set.
- `omissions` / `omitted`: reference-set IDs absent from the prediction.
- `exact`: 1 if the complete predicted and observed sets agree, 0 otherwise; summary rows count exact comparisons. Unavailable pages are unscored.
- `available`: indicator of a qualifying archived page. Blank outcome fields for unavailable pages are intentional, not zero errors.
- `same_rfc_and_text`: shared identifier with the same numeric RFC target and both original and proposed text after line-ending normalization.
- `source_sha256`: digest of the recorded source content used in an observation. Semicolon-separated ID lists are sorted numeric sets.

## Main numerical files

| File (relative to `results/`) | Observation unit and contents |
|---|---|
| `historical_panel/results.json` | Primary transition matrix, shared-ID counts, reconstructed March filing window, locked publisher outcomes and per-page sets. |
| `update_date/checkpoint_comparison.csv` | One row per historical checkpoint; matched-ID denominators, selected counts, errors and invalid update fields. |
| `update_date/per_id_predictions.csv` | One row per shared identifier and cutoff; status and membership indicators. |
| `update_date/december_omissions.csv` | One row per omitted December correction; endpoint metadata, unchanged-field tests and observed status history. |
| `update_date/publisher_page_comparison.csv` | One row per original selected RFC; restricted comparison of status and date-based predictions. |
| `full_registry/full_registry_comparison.csv` | One row per historical checkpoint; complete earlier reference set, selectors, true positives, additions, omissions, invalid dates and outside-earlier IDs. |
| `full_registry/full_id_predictions.csv` | One row per identifier in the union of the earlier and later registry at each cutoff; earlier/later presence and selector decisions. |
| `full_registry/stable_text_comparison.csv` | Checkpoint-level sensitivity restricted to shared records with unchanged target and text. |
| `full_registry/missing_earlier_records.csv` | Earlier-only IDs and earlier dispositions. |
| `full_registry/outside_earlier_ids.csv` | Selected IDs absent from the earlier registry, by cutoff and selector. |
| `full_registry/selection_errors.csv` | Per-ID membership discrepancies with status, date and text-stability fields. |
| `publisher_pages/page_predictions.csv` | Page-by-selector rows for locked disagreement, locked agreement and previously selected diagnostic captures. Current-only selectors receive no historical ID list. |
| `publisher_pages/membership_errors.csv` | Individual extra or omitted IDs for each scored page and selector. |
| `publisher_pages/summary.csv` | Group-by-selector counts of selected/scored pages, exact matches, additions and omissions. |

## Supporting records

`registry_history/errata/` contains the matched panel, revision and transition ledgers, notes-screening results and representation checks. Revision timestamps are mirror observations rather than exact publisher decision timestamps. `locked_publisher_test/publisher_holdout/` retains the original protocol and frozen comparison. `software_cases/` retains separate project cohorts, closure classifications and executable observations, including negative outcomes. `earlier_kpi/` retains its original analytic file names, distinct study units and provenance; the original trial classifications are not altered.

JSON results preserve their original schema and source references. The two full-registry and publisher-page comparisons and the update-date extension reuse existing historical records. They are not new acquisitions or prospective validation samples.
