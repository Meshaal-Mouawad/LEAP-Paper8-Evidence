# Supplementary material

**Article:** Which RFC Corrections Counted Then? Reconstructing Historical Verification References  
**Author:** Meshaal Obaid Mouawad  
**Journal:** Science of Computer Programming (Research Paper)

This archive supplies the recorded inputs, numerical results and replay programs supporting the manuscript. The principal experiments examine historical RFC erratum status, correction-set membership, date-based retrieval, and archived publisher displays. Supporting materials cover software issue histories, executable case evidence and the earlier KPI archival audits.

## Contents

| Directory or file | Description |
|---|---|
| `data/source_records.zip` | 845 original technical source files, including the dated registries, source metadata, locked predictions, archived publisher responses, and supporting software histories and recorded executions. |
| `data/source_inventory.csv` | Byte count and SHA-256 for each original source file. |
| `data/provenance.json` | Original and curated archive identifiers and documented exclusions. |
| `results/historical_panel/` | Primary matched-registry analysis and the locked publisher comparison. |
| `results/update_date/` | Five-checkpoint analysis with the update-date cutoff and omission records. |
| `results/full_registry/` | Current-only selectors, membership errors, missing-ID and unchanged-text controls. |
| `results/publisher_pages/` | Complete-page comparisons for the original sample and separate diagnostic captures. |
| `results/registry_history/` | Status-transition ledgers, rendering observations and historical filing-window results. |
| `results/locked_publisher_test/` | Original protocol, prediction lock, predictions and outcome record. |
| `results/software_cases/` | Issue-history comparisons, recorded case results and execution ledgers. |
| `figure_data/` | Data for regenerating the five manuscript figures. |
| `earlier_kpi/` | Previously curated derived-data replication materials and executable examples. |
| `code/` | Numerical replay and figure-generation programs. |
| `verify.py`, `SHA256SUMS.txt` | Offline verification and package file-integrity manifest. |
| `Data_Dictionary.md` | Definitions of units, selectors, errors and key data files. |

## Reproduction

Extract the outer ZIP. From the directory containing `verify.py`, run:

```sh
python3 -B verify.py
```

Python 3.11 or later is required. The verification uses the standard library, operates on local records, and needs no account credentials, live service or external download. It extracts the technical source archive into a temporary directory, checks all original member digests, recalculates the four principal analyses, and checks the supplied software-case and KPI records. The stored outputs are compared without changing them. The replay's archive digest reflects the curated ZIP; the reference results retain the digest of the original complete research archive. All other fields are compared, and the CSV outputs must match byte-for-byte.

To regenerate the figures, install the separately listed plotting dependency and run `python3 -B code/create_figures.py`. The resulting PDF, SVG and PNG files will be written to `figures/`. This optional step uses the recorded figure data, not new observations.

For direct inspection of source records, extract `data/source_records.zip`. The original internal directory hierarchy is retained so that the original source scripts and their relative file references remain usable. The source archive is a curated subset, not a replacement for the full research archive. Do not use acquisition flags when reproducing historical outcomes.

## Interpretation and scope

The December 2022–November 2026 matched panel contains 6,772 shared identifiers. Current status adds 294 historical nonmembers and omits one earlier Verified correction. Six previously processed records changed status with unchanged normalized target and correction text. The original locked experiment contains 12 disagreement pages and 12 agreement controls, with one unavailable control left unscored. On the 23 retrievable pages, the dated filter recovers all displays in the matched-ID comparison. The later current-only date comparisons are retrospective, and the six diagnostic captures are separate from that locked sample. These distinctions are preserved throughout the files.

The earlier KPI records contain derived analyses; the original controlled assessment logs and the underlying masked-assessment records are not part of this release. Their provenance and methods are described in the manuscript. Earlier curated KPI materials retain their original provenance statement. The complete research archive remains available separately for authorized review.

The full public Git mirror bundle, an external article PDF and the external software deposit are omitted to avoid unnecessary redistribution. The saved history ledgers and original history scripts are included. Full Git-history reconstruction requires obtaining the public mirror (https://github.com/reschke/rfc-errata), preserving the pinned commit range specified in `errata/aggregate_history.py`, then running that script with `--git-dir` pointing to the bare mirror and `errata/history.py --repo <bare-mirror> --check`. The original published-loader replay additionally requires the cited deposit (https://doi.org/10.5281/zenodo.8008032), the cited publication, and the recorded Python environment; see `errata/tma_reconstruction/REPLAY.md` and `errata/crosscheck.md`. The included offline verification checks the saved history counts and the March cohort comparison; it does not rebuild the full external mirror or rerun the external original loader.

## Source and availability information

Existing dataset identifier: https://doi.org/10.7910/DVN/DC2FOK  
Research repository: https://github.com/Meshaal-Mouawad/LEAP-Paper8-Evidence

This ZIP is the curated supplementary package accompanying the final manuscript; the identifier above is the existing earlier dataset, not evidence that this expanded package has already been deposited or published. Source locations, capture dates, commit IDs and original checksums are retained. The original source materials, including RFC content and archived publisher pages and software records, remain subject to their respective attribution, copyright and distribution terms. Inclusion for editorial verification does not assign new rights or a license to third-party materials. Confirm applicable redistribution permissions before making the archive publicly available.
