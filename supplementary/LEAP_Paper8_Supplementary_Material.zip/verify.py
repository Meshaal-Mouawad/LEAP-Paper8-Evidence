#!/usr/bin/env python3
"""Check source integrity and reproduce the numerical results offline."""
import csv, gzip, hashlib, json, os, subprocess, sys, tempfile, zipfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'data/source_records.zip'
PREFIX = 'LEAP_Paper8_R35_Research/'
PROVENANCE = json.loads((ROOT/'data/provenance.json').read_text())
def sha(b): return hashlib.sha256(b).hexdigest()
def require(test, label):
    if not test: raise RuntimeError(label)
def run(script,*args):
    env=dict(os.environ);env.pop('PYTHONOPTIMIZE',None);env['PYTHONDONTWRITEBYTECODE']='1'
    cmd=[sys.executable,'-B',str(script),*(str(a) for a in args)]
    result=subprocess.run(cmd,cwd=script.parent,env=env,text=True,capture_output=True)
    require(result.returncode==0, f'{script.name}: {result.stdout[-2000:]} {result.stderr[-4000:]}')
    return result.stdout

def compare_json(actual,expected):
    a=json.loads(actual);e=json.loads(expected)
    require(a.pop('archive_sha256')==PROVENANCE['curated_source_archive_sha256'],'replay source digest')
    require(e.pop('archive_sha256')==PROVENANCE['source_archive_sha256'],'reference source digest')
    require(a==e,'numerical or metadata difference')

def main():
    require(sys.version_info >= (3,11),'Python 3.11+ required')
    require(not sys.flags.optimize,'Run without -O or -OO')
    with (ROOT/'SHA256SUMS.txt').open() as f:
        entries=[line.rstrip('\n').split('  ',1) for line in f]
    for expected,rel in entries:
        p=ROOT/rel;require(p.resolve().is_relative_to(ROOT) and p.is_file() and sha(p.read_bytes())==expected,rel)
    print(f'PASS {len(entries)} supplement file checksums',flush=True)
    require(sha(SOURCE.read_bytes())==PROVENANCE['curated_source_archive_sha256'],'source ZIP digest')
    with tempfile.TemporaryDirectory(prefix='verification-replay-') as tmp:
        work=Path(tmp)
        with zipfile.ZipFile(SOURCE) as z, (ROOT/'data/source_inventory.csv').open(newline='') as f:
            records=list(csv.DictReader(f));require(len(records)==len(z.namelist())==PROVENANCE['source_members'],'source count')
            require(set(z.namelist())=={r['archive_member'] for r in records},'source membership')
            for r in records:
                n=r['archive_member'];b=z.read(n);require(len(b)==int(r['bytes']) and sha(b)==r['sha256'],n)
                target=work/n;require(target.resolve().is_relative_to(work),n);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
        print(f'PASS {len(records)} original source records',flush=True)
        out=run(ROOT/'code/replay_historical_panel.py',SOURCE)
        compare_json(out,(ROOT/'results/historical_panel/results.json').read_text());print('PASS historical registry and locked publisher comparison',flush=True)
        for name,script in [('update_date','replay_update_date.py'),('full_registry','replay_full_registry.py'),('publisher_pages','replay_publisher_pages.py')]:
            target=work/name;run(ROOT/'code'/script,SOURCE,target)
            expected=ROOT/'results'/name
            require({p.name for p in target.iterdir()}=={p.name for p in expected.iterdir()},name+' output file set')
            for p in target.iterdir():
                e=expected/p.name
                if p.name=='results.json':compare_json(p.read_text(),e.read_text())
                else: require(p.read_bytes()==e.read_bytes(),name+'/'+p.name)
            print('PASS '+name+' (all outputs)',flush=True)
        source=work/PREFIX
        # These scripts check the archived data; they do not fetch fresh data or execute upstream builds.
        for rel,args in [('errata/panel.py',['--check']),('errata/publisher_views.py',['--check']),('publisher_holdout/verify.py',[]),('tracker_comparison/compare.py',['--check']),('holdout/study.py',['--check']),('holdout/trace_discrepancies.py',['--check']),('cpython/verify.py',[]),('go/scripts/verify.py',[]),('standards/verify.py',[])]:
            run(source/rel,*args); print('PASS '+rel,flush=True)
        # Recheck the stored full-history ledger. Full Git reconstruction requires the original public mirror.
        errata=source/'errata';summary=json.loads((errata/'aggregate_history_summary.json').read_text())
        with (errata/'aggregate_history_events.csv').open(newline='') as f: events=list(csv.DictReader(f))
        with (errata/'aggregate_history_revisions.csv').open(newline='') as f: revisions=list(csv.DictReader(f))
        require(len(events)==617==summary['anchored_path_total_state_changes'],'history changes')
        require(len({v['id'] for v in events})==608==summary['number_of_changed_ids'],'history affected IDs')
        require(dict(Counter(v['old']+' -> '+v['new'] for v in events))==summary['anchored_path_edge_transition_counts'],'history transition counts')
        require(len(revisions)==3941==summary['ancestry_commits'],'history revision count')
        require(len({r['blob'] for r in revisions})==730==summary['distinct_json_blobs_in_range'],'history blob count')
        print('PASS stored full-history counts',flush=True)
        for script,outs in [('notes_screen.py',['notes_results.json','notes_candidates.csv']),('representation_probes.py',['representation_results.json'])]:
            originals={x:(errata/x).read_bytes() for x in outs};run(errata/script)
            require(all((errata/x).read_bytes()==v for x,v in originals.items()),script+' regenerated outputs')
            print('PASS '+script,flush=True)
        out=run(ROOT/'earlier_kpi/code/reproduce_curated.py');require(json.loads(out)['status']=='PASS','KPI derived records')
        print('PASS earlier KPI derived-data check',flush=True)
    print('All included offline verification checks passed.',flush=True)
if __name__=='__main__':main()
